aoTuV beta4.51 release note

"aoTuV" tunes up Xiph.Org's libvorbis uniquely. 
A license is taken as "BSD-style license" as well as original libvorbis. 


# NOTICE #

  Manuke's patch is used for improvement in the speed of sort processing. 
  When "#define OPT_SORT" of "lib/psy.h" is deleted, the conventional 
  processing method is used.


Thanks! Manuke.



aoTuV based on <Xiph.Org libvorbis>

Copyright (c) 2002-2005 Xiph.Org Foundation
Copyright (c) 2003-2005 Aoyumi


AUTHOR : aoyumi <aoyumi@inter7.jp>