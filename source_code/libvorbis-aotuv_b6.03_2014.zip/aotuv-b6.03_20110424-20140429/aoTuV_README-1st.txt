aoTuV Beta 6.03

"aoTuV" tunes up Xiph.Org's libvorbis uniquely. 
A license is taken as "BSD-style license" as well as original libvorbis. 


aoTuV based on <Xiph.Org libvorbis>

Copyright (c) 2002-2014 Xiph.Org Foundation
Copyright (c) 2003-2014 Aoyumi


AUTHOR : Aoyumi <aoyumi@gmail.com>
