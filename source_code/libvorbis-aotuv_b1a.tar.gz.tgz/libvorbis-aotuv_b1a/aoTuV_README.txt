"aoTuV" tunes up libvorbis 1.0.1 uniquely. 
A license is taken as "BSD-style license" as well as original libvorbis. 


# NOTICE #

 On the frequency of 26kHz or more, q-2(nominal 40kbps/44.1-48kHz) can be used. 
 A part of Nominal bitrate has changed. 
 In the low bit rate (e.g. q-2), it is easy to clip. 



aoTuV based on <Xiph.Org libvorbis 1.0.1>

Copyright (c) 2002,2003 Xiph.Org Foundation
Copyright (c) 2003,2004 Aoyumi


AUTHOR : aoyumi <aoyumi@inter7.jp>